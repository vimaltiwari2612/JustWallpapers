package com.example.justquotes;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.WindowManager;
import android.widget.AbsListView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.wenchao.cardstack.CardStack;

import java.io.File;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class MainActivity extends AppCompatActivity implements CardStack.CardEventListener{

    List<Bitmap> wallpapers;
    int width,height,start,end,range;
    RequestProcessor requestProcessor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
    }

    private void populateScreenResolution(Context context)
    {
        WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        Display display = wm.getDefaultDisplay();
        DisplayMetrics metrics = new DisplayMetrics();
        display.getMetrics(metrics);
        width = metrics.widthPixels;
        height = metrics.heightPixels;
    }

    private void init(){
        wallpapers = new ArrayList<Bitmap>();
        populateScreenResolution(this);
        range = 10;
        getData(10,10+range,false);
    }

    private void getData(int start,int end,boolean isBackgroundTask){
        this.start = start;
        this.end = end;
        requestProcessor = new RequestProcessor(this,isBackgroundTask);
        requestProcessor.execute("https://i.picsum.photos/id/");
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    public void buildFrame(){
        CardStack cardStack = (CardStack) findViewById(R.id.container);
        cardStack.setAdapter(new QuotesAdaptor(this,R.layout.list_item_view,this.wallpapers));
        cardStack.setStackMargin(20);
        cardStack.setListener(this);
        cardStack.setBackgroundColor(Color.LTGRAY);
    }

    @Override
    public boolean swipeEnd(int direction, float distance) {
        //if "return true" the dismiss animation will be triggered
        //if false, the card will move back to stack
        //distance is finger swipe distance in dp

        //the direction indicate swipe direction
        //there are four directions
        //  0  |  1
        // ----------
        //  2  |  3
        //System.out.println("swipeEnd");
        return (distance > 300)?true:false;
    }

    @Override
    public boolean swipeStart(int i, float v) {
        return true;
    }

    @Override
    public boolean swipeContinue(int i, float v, float v1) {
        return true;
    }

    @Override
    public void discarded(int i, int i1) {
        System.out.println("image number : "+i+" end "+end);
        if(i +range + range - 1 >= end){
            System.out.println("calling more images");
            getData(end+1,end+range,true);
        }
    }

    @Override
    public void topCardTapped() {
    }


    class QuotesAdaptor extends ArrayAdapter<Bitmap> {
        List<Bitmap> wallpapers;
        //activity context
        Context context;
        //the layout resource file for the list items
        int resource;
        //dir
        final File dir;

        //constructor
        public QuotesAdaptor(Context context,int resource, List<Bitmap> wallpapers){
            super(context,resource,wallpapers);
            this.context = context;
            this.wallpapers = wallpapers;
            this.resource = resource;
            this.dir = ScreenshotUtils.getMainDirectoryName(this.context);
        }

        @NonNull
        @Override
        public View getView(final int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            LayoutInflater layoutInflater = LayoutInflater.from(context);
            //getting the view
            View view = layoutInflater.inflate(resource, null, false);
            ImageView imageView = (ImageView) view.findViewById(R.id.imageView);
            imageView.setImageBitmap(this.wallpapers.get(position));

            //for download
            /*final String fileName = "JustQuote"+position+".png";

            ImageButton download = (ImageButton)view.findViewById(R.id.download);
            download.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Toast.makeText(getApplicationContext(),"Saving... ", Toast.LENGTH_SHORT).show();
                    File file = ScreenshotUtils.store(ScreenshotUtils.getScreenShot(v),fileName,dir);
                    Toast.makeText(getApplicationContext(),"Saved as "+file.getName()+" at "+file.getAbsolutePath(), Toast.LENGTH_SHORT).show();
                }
            });

            //for share
            ImageButton share = (ImageButton)view.findViewById(R.id.share);
            share.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Toast.makeText(getApplicationContext(),"Share to..." , Toast.LENGTH_SHORT).show();
                    Intent sharingIntent = new Intent(android.content.Intent.ACTION_SEND);
                    sharingIntent.setType("text/plain");

                    String shareSub = "Just Quote";
                    sharingIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, shareSub);

                    startActivity(Intent.createChooser(sharingIntent, "Share using"));
                }
            });
*/
            return view;
        }
    }
}
