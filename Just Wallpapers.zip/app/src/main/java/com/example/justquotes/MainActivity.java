package com.example.justquotes;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.DisplayMetrics;
import android.view.ContextMenu;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.WindowManager;
import android.widget.AbsListView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.wenchao.cardstack.CardStack;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class MainActivity extends AppCompatActivity implements CardStack.CardEventListener{

    List<Bitmap> wallpapers;
    int width,height,start,end,range,currentImagePostion;
    RequestProcessor requestProcessor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v,
                                    ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu, menu);
    }

    private void populateScreenResolution(Context context)
    {
        WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        Display display = wm.getDefaultDisplay();
        DisplayMetrics metrics = new DisplayMetrics();
        display.getMetrics(metrics);
        width = metrics.widthPixels;
        height = metrics.heightPixels;
    }

    private void init(){
        wallpapers = new ArrayList<Bitmap>();
        populateScreenResolution(this);
        range = 10;
        currentImagePostion = 1;
        getData(10,10+range,false);
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        return this.performAction(item);
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
       return this.performAction(item);
    }

    private boolean performAction(MenuItem item){
        switch (item.getItemId()) {
            case R.id.download:
                this.download(getData());
                return true;
            case R.id.share:
                this.share();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private Wallpaper getData(){
        Wallpaper wallpaper = new Wallpaper(this.wallpapers.get(currentImagePostion - 1),"Just Wallpaper "+currentImagePostion +" "+Calendar.getInstance().getTime());
        return wallpaper;
    }

    private String download(Wallpaper wallpaper){
        String path = MediaStore.Images.Media.insertImage(getContentResolver(), wallpaper.getWallpaper(), wallpaper.getName() , "");
        Toast.makeText(getApplicationContext(),"Downloaded "+wallpaper.getName(),Toast.LENGTH_LONG).show();
        return path;
    }

    private void share(){
        try {
            Wallpaper wallpaper = this.getData();
            String path = this.download(wallpaper);
            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setType("image/png");
            intent.putExtra(Intent.EXTRA_STREAM, Uri.parse(path));
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(Intent.createChooser(intent, "Share"));
            Toast.makeText(getApplicationContext(),"Sharing...",Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(getApplicationContext(),"Error in Sharing..."+e.getMessage(),Toast.LENGTH_LONG).show();
        }


    }

    private void getData(int start,int end,boolean isBackgroundTask){
        this.start = start;
        this.end = end;
        requestProcessor = new RequestProcessor(this,isBackgroundTask);
        requestProcessor.execute("https://i.picsum.photos/id/");
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    public void buildFrame(){
        CardStack cardStack = (CardStack) findViewById(R.id.container);
        cardStack.setAdapter(new WallpaperAdaptor(this,R.layout.list_item_view,this.wallpapers));
        cardStack.setStackMargin(20);
        cardStack.setListener(this);
        cardStack.setBackgroundColor(Color.LTGRAY);
    }

    @Override
    public boolean swipeEnd(int direction, float distance) {
        //if "return true" the dismiss animation will be triggered
        //if false, the card will move back to stack
        //distance is finger swipe distance in dp

        //the direction indicate swipe direction
        //there are four directions
        //  0  |  1
        // ----------
        //  2  |  3
        //System.out.println("swipeEnd");
        return (distance > 300)?true:false;
    }

    @Override
    public boolean swipeStart(int i, float v) {
        return true;
    }

    @Override
    public boolean swipeContinue(int i, float v, float v1) {
        return true;
    }

    @Override
    public void discarded(int i, int i1) {
        this.currentImagePostion = i;
        System.out.println("image number : "+currentImagePostion+" end "+end);
        if(i +range + range - 1 >= end){
            System.out.println("calling more images");
            getData(end+1,end+range,true);
        }
    }

    @Override
    public void topCardTapped() {
    }


    class WallpaperAdaptor extends ArrayAdapter<Bitmap> {
        List<Bitmap> wallpapers;
        //activity context
        Context context;
        //the layout resource file for the list items
        int resource;

        //constructor
        public WallpaperAdaptor(Context context,int resource, List<Bitmap> wallpapers){
            super(context,resource,wallpapers);
            this.context = context;
            this.wallpapers = wallpapers;
            this.resource = resource;
        }

        @NonNull
        @Override
        public View getView(final int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            LayoutInflater layoutInflater = LayoutInflater.from(context);
            //getting the view
            View view = layoutInflater.inflate(resource, null, false);
            ImageView imageView = (ImageView) view.findViewById(R.id.imageView);
            imageView.setImageBitmap(this.wallpapers.get(position));
            return view;
        }
    }

    public class Wallpaper {
        Bitmap wallpaper;
        String  name;

        public Wallpaper(Bitmap wallpaper, String name) {
            this.wallpaper = wallpaper;
            this.name = name;
        }

        public Bitmap getWallpaper() {
            return wallpaper;
        }

        public void setWallpaper(Bitmap wallpaper) {
            this.wallpaper = wallpaper;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }
    }
}
