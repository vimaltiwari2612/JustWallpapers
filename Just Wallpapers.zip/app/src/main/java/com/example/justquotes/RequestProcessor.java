package com.example.justquotes;
import android.app.ProgressDialog;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Build;

import androidx.annotation.RequiresApi;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;

import javax.net.ssl.HttpsURLConnection;


public class RequestProcessor extends AsyncTask<String, String, String> {

    private ProgressDialog progressDialog;
    private MainActivity mainActivity;
    private boolean isBackgroundTask;

    public RequestProcessor(MainActivity mainActivity,boolean isBackgroundTask) {
        this.mainActivity = mainActivity;
        this.isBackgroundTask = isBackgroundTask;
    }

    @Override
    protected String doInBackground(String... uri) {
        URL githubEndpoint;
        HttpsURLConnection con = null;
        InputStream in = null;
        Bitmap bmp;

        // Create connection
        try {
            for(int i = mainActivity.start ; i<=mainActivity.end ;i++){
                // Create URL
                githubEndpoint = new URL(uri[0]+i+"/"+mainActivity.width+"/"+mainActivity.height+".jpg");
                 con = (HttpsURLConnection) githubEndpoint.openConnection();
                con.setRequestMethod("GET");
                int responseCode = con.getResponseCode();
                System.out.println("Resposse code : "+responseCode);
                if (responseCode == HttpURLConnection.HTTP_OK) { // success
                    in = con.getInputStream();
                    bmp = BitmapFactory.decodeStream(in);

                    this.mainActivity.wallpapers.add(bmp);
                    System.out.println("Image fetched with id "+i);
                } else {
                    System.out.println("GET request not worked");
                }
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
            e.printStackTrace();
        }
        finally {
            try {

                con.disconnect();
                in.close();
            }catch (Exception e){

            }
        }
        return null;
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onPostExecute(String result) {
        //Do anything with response.
        if(!this.isBackgroundTask) {
            this.mainActivity.buildFrame();
            progressDialog.dismiss();
        }
    }

    @Override
    protected void onPreExecute() {
        if(!this.isBackgroundTask) {
            progressDialog = new ProgressDialog(this.mainActivity);
            progressDialog.setMax(100);
            progressDialog.setMessage("Getting data....");
            progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            progressDialog.show();
        }
    }
}
